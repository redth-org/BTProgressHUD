You may want to redescribe your component here, but the purpose of this
document is to guide the user through creating their first app using
your component.

```csharp
using MyComponentNameSpace;
...

public override void ViewDidLoad ()
{
	// Be sure to include code samples for all supported platforms
}
```

## Other Resources

* [Component Documentation](http://google.com)
* [Support Forums](http://google.com)
* [Source Code Repository](http://google.com)
